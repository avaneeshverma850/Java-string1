
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String name="Avaneesh";
        String a1=new String("aVANEESH");
        System.out.println(a1);
        int value=a1.length();
        String l1=a1.toLowerCase();
        String l2=a1.toUpperCase();
        System.out.println(l1);
        System.out.println(l2);
        System.out.println(value);
        String nontrim="   Avaneesh";
        System.out.println(nontrim.trim());
        System.out.println(a1.substring(0));
        System.out.println(a1.substring(1,3));
        System.out.println(a1.replace('A','C'));
        System.out.println(a1.charAt(5));
        System.out.println(a1.indexOf("V"));
        System.out.println(a1.equals("verma"));
        System.out.println(a1.equalsIgnoreCase("avaneesh"));
        System.out.println("I am Avaneesh Verma \\ from Devri Kumhi Sultanpur Uttarpradesh");

    }
}